class abc:
    a=5
    def display(self):
        print("hiii")

obj = abc()
obj.display()
print(obj.a)